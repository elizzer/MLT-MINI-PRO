function highlight(startIndex, endIndex) {
    var sentence = document.getElementById('sentence').value;

    if (isNaN(startIndex) || isNaN(endIndex) || startIndex < 1 || endIndex > sentence.length || startIndex > endIndex) {
        alert("Invalid start or end index");
        return;
    }

    var highlighted_word = sentence.substring(startIndex - 1, endIndex);

    var highlighted_sentence = sentence.replace(highlighted_word, '<span class="highlight">' + highlighted_word + '</span>');

    document.getElementById('highlighted_sentence').innerHTML = highlighted_sentence;
}
